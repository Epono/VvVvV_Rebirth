(c) Exit Games GmbH  - 2014
    developer@exitgames.com
---------------------------

This package is a sandbox demo of the "Photon Turnbased" features.

More: 
http://doc.exitgames.com/en/turnbased
